
# Program - MATLAB and SIMULINK - Mathworks



**Self-paced online courses by Mathworks using MATLAB and SIMULINK**
**Link : [https://matlabacademy.mathworks.com/](https://matlabacademy.mathworks.com/)**

**My Courses**

[https://matlabacademy.mathworks.com/mycourses](https://matlabacademy.mathworks.com/mycourses)

Username : ajay126z
Password : Poojay@9397

---
[MATLAB Basics](https://app.asana.com/0/0/1202673644550602)
[Course - MATLAB On-ramp - Mathworks - Notes](https://app.asana.com/0/0/1202407741530867)

[Machine Learning:](https://app.asana.com/0/0/1202673644550605)
[Course - Machine Learning On Ramp - Mathworks - Notes](https://app.asana.com/0/0/1202449056864780)
[Course - Deep Learning Onramp - MathWorks - Notes](https://app.asana.com/0/0/1202473001877528)
[Reinforcement Learning Onramp](https://app.asana.com/0/0/1202442920066046)

[Image Processing](https://app.asana.com/0/0/1202673644550608)
[Signal Processing Onramp](https://app.asana.com/0/1202402677116934/1202499330774906)
[Image Processing Onramp](https://app.asana.com/0/0/1202442920066047)

[Control Systems (MBD):](https://app.asana.com/0/0/1202673644550609)
[Optimisation On-ramp - Notes](https://app.asana.com/0/0/1202407741530873)
[Simulink Onramp](https://app.asana.com/0/1202402677116934/1202442920066042)
[Control Design Onramp with Simulink](https://app.asana.com/0/0/1202442920066052)
[Stateflow Onramp](https://app.asana.com/0/0/1202442920066051)

[Circuit and Communication Systems:](https://app.asana.com/0/0/1202673644550612)
[Circuit Simulation Onramp](https://app.asana.com/0/0/1202442920066043)
[Wireless Communications Onramp](https://app.asana.com/0/0/1202442920066049)
[Simscape Onramp](https://app.asana.com/0/0/1202442920066050)