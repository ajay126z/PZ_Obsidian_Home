Up:: [[MOOC Courses MOC]]
CourseSource:: Youtube
tags:: #source/course 

# Start up

- [[How to Start a Startup by Y Combinator]] Youtube Playlist URL Link : 
Playlist Link : [How to Start a Startup - Y Combinator YouTube Playlist](https://youtube.com/playlist?list=PL5q_lef6zVkaTY_cT1k7qFNF2TidHCe-1)



# Technical

## Computer Vision
Superb Lecture series on Computer Vision by Professor Shree Nayar from Columbia University. 
- [[First Principles of Computer Vision]]
[First Principles of Computer Vision - YouTube Channel](https://youtube.com/@firstprinciplesofcomputerv3258)
