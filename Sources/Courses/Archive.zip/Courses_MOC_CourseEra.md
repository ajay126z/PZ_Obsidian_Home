Up:: [[MOOC Courses MOC]]
CourseSource:: CourseEra
tags:: #source/course 

## General
- Science of Well Being
- Writing in A Science 
- Learning How to Learn: Powerful mental tools to help you master tough subjects

## Data, ML & AI
Machine Learning
Introduction to Embedded Machine Learning

## Automotive
Modeling and Debugging Embedded Systems
Introduction to battery-management systems
Electric Vehicles and Mobility