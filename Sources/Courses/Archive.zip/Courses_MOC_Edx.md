Up:: [[MOOC Courses MOC]]
CourseSource:: EdX
tags:: #source/course


# EdX Course Overview

# Technology

## Automotive

Decision Making for Autonomous Systems 
Sensor Fusion and Non Linear Filtering for Automotive Systems
Hybrid Vehicles 
Road Traffic Safety in Automotive Engineering
Electric and Conventional Vehicles 
Model Based Automotive Systems Engineering 
Multi-Object tracking for Automotive Systems
Embedded Systems - Shape the world

## General Programming Concepts
Introduction to Java Programming 
The Beauty and Joy of Computing (CS Principles)
Implementation of Data Structures
Foundation of Computer Graphics
Introduction to Linux
How to Win Coding Competitions : Secret of Champions

## Data, ML & AI
Learning from Data (Introductory Machine Learning Course)
Artificial Intelligence 
Data Science and Machine Learning Essentials
Scalable Machine Learning

## Applied Engineering
Solar Energy
Autonomous Mobile Robots

## Pure Science
Classical Mechanics
Discrete Time Signals and Systems 
Introduction to the Probability: Science of Uncertainty 

# Business 

## Entrepreneurship
Introduction to Project Management
Excel for Everyone: Core Foundations
Entrepreneurship 101: Who is Your customer 
Innovation Generation: How to be Creative 
Innovation and Commercialization 


# Personal Development

## Wellness
The Science of Happiness
Learn Like a Pro : Science Based Tools to become better at anything 
The science of Everyday thinking 
Question Everything: Scientific thinking in Real Life

## Communication
Conquering Humor Fundamentals
Introduction to Public Speaking
Effective Visual Communication - EdX
Storytelling in the Workplace 

## Music
Music Technology Foundations
Music for Wellness 
Introduction to the Music Business


