Up:: [[MOOC Courses MOC]]
CourseSource:: Udacity
tags:: #source/course 

Below are the courses which Ajay needs to plan to complete by this year.

1.  **Software Architecture & Design : [https://www.udacity.com/course/software-architecture-design--ud821](https://www.udacity.com/course/software-architecture-design--ud821)**
    
2.  **Introduction to Operating Systems : [https://www.udacity.com/course/introduction-to-operating-systems--ud923](https://www.udacity.com/course/introduction-to-operating-systems--ud923)**
    
3.  **Writing READMEs** : [https://classroom.udacity.com/courses/ud777](https://classroom.udacity.com/courses/ud777)
    
4.  **Human-Computer Interaction : [https://www.udacity.com/course/human-computer-interaction--ud400](https://www.udacity.com/course/human-computer-interaction--ud400)**
    
5.  **Compilers: Theory and Practice : [https://www.udacity.com/course/compilers-theory-and-practice--ud168](https://www.udacity.com/course/compilers-theory-and-practice--ud168)**
    
6.  **GT - Refresher - Advanced OS : [https://www.udacity.com/course/gt-refresher-advanced-os--ud098](https://www.udacity.com/course/gt-refresher-advanced-os--ud098)**
    
7.  **Intro to Theoretical Computer Science : [https://www.udacity.com/course/intro-to-theoretical-computer-science--cs313](https://www.udacity.com/course/intro-to-theoretical-computer-science--cs313)**
    
8.  **Intro to Algorithms : [https://learn.udacity.com/courses/cs215/welcome-flow](https://learn.udacity.com/courses/cs215/welcome-flow)**
    
9.  **Embedded Systems :** 
    
10.  **Computability, Complexity & Algorithms : [https://www.udacity.com/course/computability-complexity-algorithms--ud061](https://www.udacity.com/course/computability-complexity-algorithms--ud061)**
    
11.  **Advanced Operating Systems : [https://www.udacity.com/course/advanced-operating-systems--ud189](https://www.udacity.com/course/advanced-operating-systems--ud189)**
    
12.  **Applied Cryptography : [https://www.udacity.com/course/applied-cryptography--cs387](https://www.udacity.com/course/applied-cryptography--cs387)**
    
13.  **C++ For Programmers : [https://www.udacity.com/course/c-for-programmers--ud210](https://www.udacity.com/course/c-for-programmers--ud210)**
    
14.  **How to Make an iOS App : [https://www.udacity.com/course/how-to-make-an-ios-app--ud607](https://www.udacity.com/course/how-to-make-an-ios-app--ud607)**
    
15.  **iOS Design Patterns : [https://www.udacity.com/course/ios-design-patterns--ud1029](https://www.udacity.com/course/ios-design-patterns--ud1029)**
    
16.  **Google Maps APIs : [https://classroom.udacity.com/courses/ud864](https://classroom.udacity.com/courses/ud864)**
    
17.  **Intro to Psychology : [https://www.udacity.com/course/intro-to-psychology--ps001](https://www.udacity.com/course/intro-to-psychology--ps001)**
18.  **Cyber-Physical Systems Design & Analysis : [https://www.udacity.com/course/cyber-physical-systems-design-analysis--ud9876](https://www.udacity.com/course/cyber-physical-systems-design-analysis--ud9876)**
    
19.  **Differential Equations in Action :** 
    
20.  **Self-Driving Fundamentals: Featuring Apollo : [https://www.udacity.com/course/self-driving-car-fundamentals-featuring-apollo--ud0419](https://www.udacity.com/course/self-driving-car-fundamentals-featuring-apollo--ud0419)**
    
21.  **Data Science Interview Prep : [https://www.udacity.com/course/data-science-interview-prep--ud944](https://www.udacity.com/course/data-science-interview-prep--ud944)**
    
22.  **Machine Learning Interview Preparation : [https://learn.udacity.com/courses/ud1001](https://learn.udacity.com/courses/ud1001)**
    
23.  **Product Manager Interview Preparation: [https://www.udacity.com/course/product-manager-interview-preparation--ud034](https://www.udacity.com/course/product-manager-interview-preparation--ud034)**

