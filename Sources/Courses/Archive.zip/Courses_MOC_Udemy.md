Up:: [[MOOC Courses MOC]]
CourseSource:: Udemy
tags:: #source/course 

# Udemy Couse Lists

## Fitness and Health
### Ayurveda
THE SPIRIT OF AYURVEDA - 60 HOUR CERTIFICATION
Ayurveda for Healthy Life Guru Course (Certification)

### Exercise
Complete Fitness Trainer Certification: Beginner To Advanced
Science-Based Bodyweight Workout: Build Muscle Without A Gym

### Yoga
"Anatomy of Yoga" 1: Teacher Training Workshop Series
"Anatomy of Yoga" 2: Teacher Training Workshop Series
"Anatomy of Yoga" 3: Teacher Training Workshop Series
10 for 10 Yoga Challenge
7 Day Home Yoga Strength Retreat
Instant Health QiGong

### Modern Biology
General Mycology - a Brief Overview


## Communication

The Complete Communication Skills Master Class for Life
Communication Skills Master Class : Speak Like a Leader
Conflict Management with Emotional Intelligence
Public Speaking Skills: Deliver Great Technology Talks
B2B Cold Email Course 2023 - 5 Figure Copywriting Blueprint
Dialogue in Dilemma- Power of Communication
The Complete Talking Head Video Production Masterclass
How to speak to anyone & be fearless - in less than 55 min
Body Language in the Workplace
Effective In-Person & Virtual Zoom Meetings
Your WORDS, Powerful Tools
Conference Calls-You Can Present Well On Any Conference Call
Speaking on the telephone: Confidently Speak on the Phone
Public Speaking - High Tech Executives can be Eloquent
Public Speaking Emergency! Ace the Speech with Little Prep
Public Speaking: Financial Advisers Convey your Expertise
The Complete Nonverbal Communication Course - Body Language
You Can Deliver a TED-Style Talk Presentation (Unofficial)

### Media Training
Media Training for Financial Service Professionals
Media Training for Authors: Promote your Book in the News
Emergency Media Training: You can face a reporter in 2 Hours
Public Relations: Media Crisis Communications
Public Speaking for People Who Hate Public Speaking


### PD
Self Discipline will Change Your life for GOOD
Podcast With NLP for High Audience Growth
Podcast with Passion and Inspiration
Podcast Storytelling Masterclass
Observe to Unmask: 100 Small Things to Know People Better
10 Laws for Personal Success - The complete Course
Complete Good Sleep Habit Course - Sleep Better Tonight
The complete Law of Attraction Course - Updated for the 2020s
Complete Goal Achievement Course - Personal Success Goals
Complete Willpower Course - Build Self Control & Good Habits
Identify And Avoid Unconscious Bias

## Career

### Automotive
Automotive Cyber Security
Autosar Architecture (Learn from Scratch with Demo) - **Completed** 
AUTOSAR DIAGNOSTICS (DEM, DCM, OBD, UDS) - **In Progress**
Automotive Vehicle Diagnostic
GNU Make & Makefile To Build C/C++ Projects - (LINUX,MAC)
Master Course in Hazard Analysis and Critical Control Points

### Web and App Development and Computing 

The Complete 2022 Web Development Bootcamp
JavaScript And PHP And Python Programming Complete Course
CSS Complete Course for Beginners
JavaScript for Beginners - The Complete introduction to JS
JavaScript How to create Dynamic and Interactive Web Pages
The Webrtc Bootcamp 2023 For Beginners
Object-Oriented Programming (OOP) - How to Code Faster 2023
Building Android Widgets from scratch (Learn 8 Widgets)
Master Course of Rapid Application Development
Complete Cyber Security Practice Tests & Interview Questions
150+ Exercises - Data Structures in Python - Hands on - 2023
110+ Exercises - Python + SQL (Sqlite3) - SQLite Databases
100+ Exercises - Advanced Python Programming - 2023
150+ Exercises - OOP Programming in Python - 2023
210+ Exercises - Python Standard Libraries - 2023
130+ Exercises - Python - Data Science - Pandas - 2023
100+ Exercises - Python - Data Science - Scikit Learn - 2023
Databases with Python: MySQL, SQLite & MongoDB with Python
SQL Bootcamp - Hands-On Exercises - SQLite - Part I - 2023
SQL Bootcamp - Hands-On Exercises - SQLite - Part II - 
Excel Tips and trick : Learn MS Excel by making 7 Projects
Master Course in Digital Transformation
Non-Fungible Tokens (NFTs): What You Must Know


### Data, ML & AI
Essential Non Technical Skills of Effective Data Scientists
Introduction to Quantum Computing
Artificial Intelligence in Web Design + Live Class
Artificial Intelligence in Digital Marketing + Live Class
Master course of Data Modeling
Developing and Deploying Applications with Streamlit
Python for Machine Learning with Numpy, Pandas & Matplotlib
Data Sonification using Two Tone- Convert your Data to Music
NLP (Natural Language Processing) Course for Beginner
Virtual Personal Assistant Development
Digital Voice cloning using Artificial Intelligence
Artificial Intelligence Music Creation (New Edition)
Fundamentals of IoT (Internet of Things)


### IT Human Skill Management
Ultimate Guide to Product Design: Design Thinking Approach
Become a Product Manager : Learn the Skills and Get a Job
Accelerated Learning: Study Skills for Success: IT industry
Developer Relations Fundamentals – DevRel Masterclass 2023
Learn Engineering Simulations With ANSYS From Scratch
How to Ask for a Raise or Promotion
Understanding Neurodiversity In The Workplace

## Business and Management

### Project Management
PMP Certification Exam Prep Project Management Professional
PMP Practice Test: Project Management Professional 2021
Agile Metrics for Agile Project Management
Kanban Metrics for Agile teams: Measure & Improve Flow
Professional Scrum with Kanban (PSK I) Certification Prep
How to Plan Your 12-Month Grants Calendar in Under an Hour
Hybrid Teams and Future of Work: Fortune 500 Leaders
Master the Strategy Language for your IT Leadership Career
Management Consulting Essential Training
RCA: Root cause analysis
Counseling and Negotiation Skills for Management
Time Management for Professional
Time Management Mastery: 10x your time, Join the New Rich.
How to Create a Professional Presentation in PowerPoint
Creative Infographics in PowerPoint
Fundamentals of Successful Leadership - Leading with Impact
Workspace Design and Organization for Productivity


### Startup
Startup 101: Fundamentals for starting a new business
Start a company in 33 minutes!
Master Course in Social Entrepreneurship 2.0
Master Course in Business Plan and Business Proposal
Master Course in Business Analysis
Master Course of Business Consulting
Strategic Partnerships and Collaborations
Master Course of Lean Startup and IT Startup
Entrepreneurship - Ft Matthew Rolnick of Yaymaker, Groupon 
Entrepreneurship and Innovation - Start your own business
Responsibility Accounting & Performance Management
Master Course in Business Model and Business Model Canvas
Economics, Energy, and Inflation

### Finance
Accounting- Financial Accounting, Cash vs Accrual Accounting
Master Course in Business Budgeting
Income Tax – Schedule C Small Business Sole Proprietor
Managerial Accounting / Cost Accounting
Process Costing System - Cost Accounting- Managerial Accounting
Introduction to Forex - Learn to trade by yourself
Flexible Budgets, Standard Costs, & Variance Analysis
Cost Volume Profit (CVP) Analysis  - Managerial Accounting
Time Value of Money & Capital Budgeting - Present Value
Financial Statement Analysis - Ratio Analysis
Financial Accounting – Payroll
Financial Accounting-Adjusting Entries & Financial Statement
Financial Accounting-Debits & Credits-Accounting Transaction
Financial Accounting-Debits & Credits-Accounting Transaction
Quantity Surveying Templates for Effective Cost Management
Basic Course to GST (Goods and Services Tax)


### HR and Career Change
Problem Solving and Career Planning: Fortune 500 Firms
Career Change: Become a Paid Expert in What You Love
Master Course in Business Etiquette
Master Course of Executive Coaching
Complete Management Coaching Course - Executive Coaching
P.O.W.E.R Resume System: Proven system to get job interviews

### Marketing & Sells
Complete Digital Advertising Course: PPC Advertising Mastery
Viral YouTube Marketing - Crash Course + Live Class
Grow your sales with Conversion Rate Optimization (CRO)
How to increase your sales: Top Practical Selling Tips
Reputation Management: Take Control of Your Company's Image
Marketing Analytics & Retail Business Management using Excel
Grow your business with Chatbot Marketing!
Google My Business. How to Master Powerful Tool for Company
Master Course of Amazon Connect
Content Marketing 2023. Content that Sells!
Google Analytics, GA4, GTM. How to improve your marketing?Inbound Marketing - Improve Your Skills Today
Google Analytics Certification. How to Pass the Exam
Facebook & Instagram Dynamic Ads: Dynamic Retargeting Course
Facebook Ads & Instagram Ads Course 2023: The Art of Selling.
Account Based Marketing (ABM) - Increase your B2B Efficiency
Google Ads 2023 - How to drive sales with PPC!

### Other Income Ideas
Myyaffiliate - 60% margin affiliate dropshipping program
Build yourself a good online income with Affiliate Marketing
Build an Amazon Affiliate E-Commerce Store from Scratch
Easiest Side Gig 2023 - Passive Income from Transcription
Teaching in Adult Education
Master Course in Online Business and Home Business
Make Money Online: Mindset Training + Real Life Examples
6 Killer Startup Business Ideas In One Masterclass Framework
See 27 Ways to Make Money Online with Your Smartphone!
Car Flipping : The Art of Running Car Business - 90 minute !
Etsy: The Ultimate Guide to Boosting your business
The Guide to Freelancing in the modern Gig Economy

### Other Skills
Plumbing Sanitary System 2023 from A-Z
practical clinical chemistry from scratch


### Trading and Investment
Complete Cryptocurrency and Bitcoin Trading Course 2023

  
## Hobbies and Recreational

### Image
Photography Masterclass : A Complete Guide to Photography
Master Course of Art Gallery Management
Engineering Drawing / Graphics : Hands-on training



### Audio 
Artificial Intelligence Powered Audiobook Creation Course

### Video Production
On Camera Charisma for YouTube Stars
Content Samurai: Super High Speed Video Creation
The Complete Introduction to Online Course Creation
Get 5 Million Free Images and Videos for Commercial Use
Video Production, YouTube Marketing, & Video Marketing Guide
Online Course Creation: Complete Course of Blunders to avoid

### Music
Learn Piano in 45 Days (Part One)


### Movie Production
How To Make Independent Feature Film On A Budget
How To Produce A Low Budget Independent Feature Film!
Simple Independent Film Screenwriting
Being Independent Movie Director
How To Design A Great Movie Poster That Works
How To Edit A Feature Film By Yourself

